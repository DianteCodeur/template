/**
 *
 * This file was generated with Adobe XD React Exporter
 * Exporter for Adobe XD is written by: Johannes Pichler <j.pichler@webpixels.at>
 *
 **/

import React from "react";

const UserInterfaceDesktopComponent = ({ svgRef }) => (
  <svg width={1280} height={900} viewBox="0 0 1280 900" ref={svgRef}>
    <defs>
      <style>
        {
          ".a{clip-path:url(#e);}.b{fill:url(#a);}.c,.t{fill:#f6f2e9;}.c,.d{opacity:0.997;}.d{fill:#d3a7ff;}.e,.i,.l{fill:#fff;}.f,.g,.o,.p{fill:none;}.f,.p{stroke:#000;}.f{stroke-width:2px;opacity:0.05;}.g,.h{stroke:#707070;}.h{font-size:14px;}.h,.l,.n,.q,.r{font-family:Montserrat-Bold, Montserrat;font-weight:700;letter-spacing:0.05em;}.i{stroke:#c4c4c4;}.j{font-size:20px;font-family:Montserrat-Medium, Montserrat;font-weight:500;}.k{fill:#9fcb9e;}.l,.n{font-size:12px;}.m{fill:#c98a8e;}.n{fill:#f9f9f9;}.p{stroke-linecap:round;stroke-linejoin:round;stroke-width:1.333px;}.q,.r{fill:#090909;}.q{font-size:17px;}.r{font-size:26px;}.s{stroke:none;}.u{filter:url(#b);}"
        }
      </style>
      <pattern
        id="a"
        preserveAspectRatio="xMidYMid slice"
        width="100%"
        height="100%"
        viewBox="0 0 3000 1832"
      >
        <image
          width={3000}
          height={1832}
          xlinkHref="ComponentTMP_0-image.jpg"
        />
      </pattern>
      <filter
        id="b"
        x={79}
        y={42}
        width={1121}
        height={834}
        filterUnits="userSpaceOnUse"
      >
        <feOffset dy={10} input="SourceAlpha" />
        <feGaussianBlur stdDeviation={10} result="c" />
        <feFlood floodColor="#bfbcb4" floodOpacity={0.161} />
        <feComposite operator="in" in2="c" />
        <feComposite in="SourceGraphic" />
      </filter>
      <clipPath id="e">
        <rect width={1280} height={900} />
      </clipPath>
    </defs>
    <g id="d" className="a">
      <rect className="t" width={1280} height={900} />
      <rect className="b" width={1280} height={900} />
      <rect className="c" width={1280} height={900} />
      <g transform="translate(-288.456 -35.552)">
        <g transform="translate(397 97.552)">
          <rect
            className="d"
            width={1061}
            height={775}
            transform="translate(1.234 1)"
          />
          <g transform="translate(0 0)">
            <g className="u" transform="matrix(1, 0, 0, 1, -108.54, -62)">
              <rect
                className="e"
                width={1061}
                height={774}
                rx={8}
                transform="translate(109 62)"
              />
            </g>
            <path
              className="f"
              d="M980.833,0H0"
              transform="translate(40.5 87.461)"
            />
            <g transform="translate(220.928 39.448)">
              <g className="g">
                <rect className="s" width={188} height={48} />
                <rect className="o" x={0.5} y={0.5} width={187} height={47} />
              </g>
              <text className="h" transform="translate(94 29)">
                <tspan x={-21.784} y={0}>
                  {"Tasks"}
                </tspan>
              </text>
            </g>
            <g transform="translate(408.928 39.448)">
              <g className="g">
                <rect className="s" width={188} height={48} />
                <rect className="o" x={0.5} y={0.5} width={187} height={47} />
              </g>
              <text className="h" transform="translate(94 29)">
                <tspan x={-23.52} y={0}>
                  {"Alerts"}
                </tspan>
              </text>
            </g>
            <g transform="translate(143.456 321)">
              <g className="i">
                <rect className="s" width={32} height={32} rx={2} />
                <rect
                  className="o"
                  x={0.5}
                  y={0.5}
                  width={31}
                  height={31}
                  rx={1.5}
                />
              </g>
              <text className="j" transform="translate(54 27)">
                <tspan x={0} y={0}>
                  {"Va activer ton VPN sinon chipeur va te chiper"}
                </tspan>
              </text>
            </g>
            <g transform="translate(143.456 414)">
              <g className="i">
                <rect className="s" width={32} height={32} rx={2} />
                <rect
                  className="o"
                  x={0.5}
                  y={0.5}
                  width={31}
                  height={31}
                  rx={1.5}
                />
              </g>
              <text className="j" transform="translate(54 27)">
                <tspan x={0} y={0}>
                  {"Va faire la vaissellle"}
                </tspan>
              </text>
            </g>
            <g transform="translate(143.456 507)">
              <g className="i">
                <rect className="s" width={32} height={32} rx={2} />
                <rect
                  className="o"
                  x={0.5}
                  y={0.5}
                  width={31}
                  height={31}
                  rx={1.5}
                />
              </g>
              <text className="j" transform="translate(54 27)">
                <tspan x={0} y={0}>
                  {"Va apprendre tes cours"}
                </tspan>
              </text>
            </g>
            <g transform="translate(143.456 600)">
              <g className="i">
                <rect className="s" width={32} height={32} rx={2} />
                <rect
                  className="o"
                  x={0.5}
                  y={0.5}
                  width={31}
                  height={31}
                  rx={1.5}
                />
              </g>
              <text className="j" transform="translate(54 27)">
                <tspan x={0} y={0}>
                  {"Va \xE9taler ton linge, il est propre"}
                </tspan>
              </text>
            </g>
          </g>
        </g>
      </g>
      <g transform="translate(840 377)">
        <rect className="k" width={221} height={48} rx={24} />
        <text className="l" transform="translate(83 29)">
          <tspan x={0} y={0}>
            {"BUTTON"}
          </tspan>
        </text>
      </g>
      <g transform="translate(840 465)">
        <path
          className="m"
          d="M24,0H197a24,24,0,0,1,0,48H24A24,24,0,0,1,24,0Z"
        />
        <text className="n" transform="translate(83 29)">
          <tspan x={0} y={0}>
            {"BUTTON"}
          </tspan>
        </text>
      </g>
      <g transform="translate(840 559)">
        <rect className="m" width={221} height={48} rx={24} />
        <text className="n" transform="translate(83 29)">
          <tspan x={0} y={0}>
            {"BUTTON"}
          </tspan>
        </text>
      </g>
      <g transform="translate(840 653)">
        <rect className="m" width={221} height={48} rx={24} />
        <text className="n" transform="translate(83 29)">
          <tspan x={0} y={0}>
            {"BUTTON"}
          </tspan>
        </text>
      </g>
      <g transform="translate(178 96)">
        <rect className="o" width={88} height={46} />
        <g transform="translate(1 1)">
          <path
            className="p"
            d="M67.4,38.1A55.013,55.013,0,0,1,44,43.333C16.424,43.333.667,23,.667,23A60.48,60.48,0,0,1,20.6,7.9M35.727,3.277A54.949,54.949,0,0,1,44,2.667C71.576,2.667,87.333,23,87.333,23a52.461,52.461,0,0,1-8.509,8.108m-26.473-2.72a16.384,16.384,0,0,1-11.571,2.19c-4.187-.69-7.457-2.8-8.526-5.5s.232-5.564,3.394-7.465"
            transform="translate(-0.667 -0.667)"
          />
          <path
            className="p"
            d="M.667.667,87.333,45.333"
            transform="translate(-0.667 -0.667)"
          />
        </g>
      </g>
      <text className="q" transform="translate(1026 135)">
        <tspan x={0} y={0}>
          {"Aide | ?"}
        </tspan>
      </text>
      <text className="r" transform="translate(312 284)">
        <tspan x={0} y={0}>
          {"Welcome to Wakanda, we'll take care of you"}
        </tspan>
      </text>
    </g>
  </svg>
);

const ForwardRef = React.forwardRef((props, ref) => (
  <UserInterfaceDesktopComponent svgRef={ref} {...props} />
));
export default ForwardRef;
